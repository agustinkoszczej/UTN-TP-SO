# CPU
La idea de este proyecto es un primer andamiaje para entender / extender el desarollo de la CPU.

Para correrlo, simplemente hay que compilarlo: `make all` y ejecutarlo `LD_LIBRARY_PATH="../parser/build/:../cspec/release/:../commons/src/build/" build/dummy-cpu`